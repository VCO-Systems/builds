-- remove the uniqueness constraint from batch_log_ok_dtl
ALTER TABLE batch_log_ok_dtl DROP CONSTRAINT PK_COL_CONSTRAINT;
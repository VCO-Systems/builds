-- must be run by system user
drop user vbatch cascade;